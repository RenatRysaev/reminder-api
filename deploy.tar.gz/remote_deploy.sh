echo 'success connected' && exit
